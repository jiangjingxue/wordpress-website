<div class="initial-content-connect py-5">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="left-column-section">
                    <div class="left-column-upper-section">
                        <div class="text-block">
                            <h1>Let's Chat</h1>
                            <p>I am happy to chat with you.</p>
                        </div>
                    </div>
                    <div class="left-column-lower-section"> 
                        <div class="d-inline-flex social-icons p-2 ps-0 bd-highlight justify-content-between">
                            <div class="p-2 ps-0 bd-highlight first-icon">
                                <a href="https://github.com/jiangjingxue">
                                    <i class="fa-brands fa-github fa-3x"></i>
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="https://account.google.com">
                                    <i class="fa-regular fa-envelope fa-3x"></i>
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="https://www.linkedin.com/in/jingxue-jiang-a731bb165">
                                    <i class="fa-brands fa-linkedin-in fa-3x"></i>
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="https://www.instagram.com/jiangj.0?igsh=MXU3aWR0d3Qzcnk2bA%3D%3D&utm_source=qr">
                                    <i class="fa-brands fa-instagram fa-3x"></i>
                                </a>
                            </div>
                            
                        </div>  
                    </div>
                </div>
            </div>
    </div>
    <!-- <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="ratio ratio-16x9">
                    <div class="corner-wrapper">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2859.115545062113!2d-76.49771612429267!3d44.22527947108069!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cd2ab0fccd925e9%3A0x268a8a4f5c257211!2sQueen&#39;s%20University!5e0!3m2!1sen!2sca!4v1704321897901!5m2!1sen!2sca" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="eager" referrerpolicy="no-referrer-when-downgrade"></iframe>                        
                    </div>
                </div>
            </div>
    </div> -->
</div>