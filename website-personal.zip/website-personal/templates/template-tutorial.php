<?php
/**
 * Template Name: Tutorial
 * The template for displaying the template page 
 */
?>
<?php get_header('tutorial');?>

<article class="content">
    <?php get_template_part('template-parts/content','tutorial'); ?> 
</article>

