<?php
/**
 * Template Name: About
 * The template for displaying the about page 
 */
?>
<?php get_header('about');?>


<?php get_footer();?>