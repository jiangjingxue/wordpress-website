<?php get_header();?>

<article class="content">

    <?php get_template_part('template-parts/content','home'); ?>

</article>

<?php get_footer();?>   